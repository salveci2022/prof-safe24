# PROF-SAFE 24

Sistema de alerta rápido para escolas, com:

- Painel do professor
- Painel central
- Integração com Telegram
- Geração de relatório PDF

## Como rodar localmente

```bash
pip install -r requirements.txt
python app.py
```

Depois acesse http://localhost:5000 no navegador.
